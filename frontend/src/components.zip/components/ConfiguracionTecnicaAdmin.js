export default function ConfiguracionTecnicaAdmin() {
  return <div>Página de Configuración Técnica Admin (en construcción)</div>;
}