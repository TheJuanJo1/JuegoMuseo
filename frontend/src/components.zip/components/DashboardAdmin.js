// DashboardAdmin.js
export default function DashboardAdmin() {
  return <div>Página de Dashboard Admin (en construcción)</div>;
}
