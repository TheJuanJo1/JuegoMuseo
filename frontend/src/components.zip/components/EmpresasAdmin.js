// EmpresasAdmin.js
export default function EmpresasAdmin() {
  return <div>Página de Empresas Admin (en construcción)</div>;
}