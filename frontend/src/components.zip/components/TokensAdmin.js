export default function TokensAdmin() {
  return <div>Página de Tokens Admin (en construcción)</div>;
}